import { Component } from '@angular/core';

@Component({
  selector: 'app-aside-destra',
  templateUrl: './aside-destra.component.html',
  styleUrls: ['./aside-destra.component.css']
})
export class AsideDestraComponent {

}
