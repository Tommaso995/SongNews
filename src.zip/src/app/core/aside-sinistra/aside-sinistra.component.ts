import { Component } from '@angular/core';

@Component({
  selector: 'app-aside-sinistra',
  templateUrl: './aside-sinistra.component.html',
  styleUrls: ['./aside-sinistra.component.css']
})
export class AsideSinistraComponent {

}
